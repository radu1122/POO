package com.oop_pub.clase_interne.LinuxOS;

import com.oop_pub.clase_interne.Bash.Bash;

public class LinuxOS {

    public static void main(String[] args) {
        Bash bash = new Bash();

        bash.start();
    }
}
