package ex2;

public interface Car {
    CarType type = CarType.GENERIC;
    //protected double topSpeed;
    //protected double cost;

    //public Car() {
    //    this.type = CarType.GENERIC;
    //}

    String showPresentation();
}
