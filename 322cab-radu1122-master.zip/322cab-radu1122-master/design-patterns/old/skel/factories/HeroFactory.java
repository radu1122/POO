package com.oop_pub.design_patterns.factories;


import com.oop_pub.design_patterns.entities.Hero;
import com.oop_pub.design_patterns.entities.Mage;
import com.oop_pub.design_patterns.entities.Priest;
import com.oop_pub.design_patterns.entities.Warrior;

public class HeroFactory {
    //TODO implement me

    public Hero createHero(Hero.Type type, String name) {
        return null;
    }
}
