package com.oop_pub.design_patterns.entities;

//TODO additional attack: magicAttack