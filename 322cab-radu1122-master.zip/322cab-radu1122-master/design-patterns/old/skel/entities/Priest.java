package com.oop_pub.design_patterns.entities;

//TODO extra attribute: knowledge
