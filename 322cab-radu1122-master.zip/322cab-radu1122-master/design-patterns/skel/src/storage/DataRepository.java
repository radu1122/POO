package storage;


/**
 * Persists sensor data. Observable, its observers are notified when data is added it to.
 */
public class DataRepository { // TODO make this an Observable

    public void addData(SensorData dataRecord){
        // TODO
        // store data (e.g. in a List)
        // notifiy observers
    }

    // TODO implement a method to get the stored data (needed by the strategies)
}


