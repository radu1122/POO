package third;

/**
 * Enumerates the types of strategies for the containers.
 */
public enum Strategy {
    FIFO, LIFO
}
