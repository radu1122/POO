package ex2;


public class MyArrayList <E>{
	/*TODO
	 * - extend ArrayList and implement Observable
	 * - override methods
	 */	
}
