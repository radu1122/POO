package game;

public class MoveCommand implements Command {


    // TODO implement the move command
    /*  - MoveCommand(Hero, Direction)
        - void undo()
        - void execute()
        - maybe helper method for undo ?
    */

}
