package game;


/**
 * Observer that prints the lore of a treasure when a hero discovers it. 
 *
 */
class TreasureDiscoverer { 
		// TODO
		// check if any hero is in an area containing a treasure
		// print some message
		// remove treasure from map and 
		// add to specific hero's inventory		
}