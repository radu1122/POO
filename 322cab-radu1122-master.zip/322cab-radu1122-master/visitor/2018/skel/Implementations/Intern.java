package com.oop_pub.visitor.Implementations;

import com.oop_pub.visitor.Visitable;
import com.oop_pub.visitor.Visitor;

//TODO implementati interfata Visitable
public class Intern {

    private String  name;
    private int duration;  // in months

    public String getName() {
        return name;
    }
}
