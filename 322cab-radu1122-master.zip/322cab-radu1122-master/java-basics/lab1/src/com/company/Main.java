package com.company;

import task2.Course;
import task2.Student;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Course curs1 = new Course();
        Student student1 = new Student();
        Student student2 = new Student();
        Student student3 = new Student();
        student1.setYear(2000);
        student1.setName("Alex");

        student2.setYear(2001);
        student2.setName("Andrei");

        student3.setYear(2002);
        student3.setName("Radu");

        curs1.setTitle("Curs de test");
        curs1.setDescription("Cel mai fain curs");

        ArrayList<Student> studentsBuffer = new ArrayList<Student>(); // Create an ArrayList object

        studentsBuffer.add(student1);
        studentsBuffer.add(student2);
        studentsBuffer.add(student3);

        curs1.setStudents(studentsBuffer);

        System.out.println(curs1.filterYear(2001));

        Student studentx = new Student();
        Student studenty = new Student();

        studentx.setYear(2002);
        studentx.setName("Radu");

        studenty.setYear(2002);
        studenty.setName("Radu");

        System.out.println(studentx.equals(studenty));

    }
}
